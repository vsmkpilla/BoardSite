-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2016 at 10:59 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airtel`
--
CREATE DATABASE IF NOT EXISTS `airtel` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `airtel`;

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(22) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `subject`, `description`, `date`) VALUES
(1, 'Fee Payment', '......................................', 'Monday 12th  December 2016 12:33:15 PM'),
(2, 'Holidays', '......................................', 'Monday 12th  December 2016 12:33:33 PM');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `regstrationid` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birthday` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`regstrationid`, `firstname`, `middlename`, `lastname`, `address`, `birthday`, `gender`, `phonenumber`, `photo`, `signature`, `date`) VALUES
('ID:19020996', 'uday sekhar', 'uday', 'u', 'smlkot', '11/03/1997', 'Male', '9542253326', 'photos/logo.jpg', 'uday', '12th  December 2016'),
('ID:23093261', 'Uday', 'kumar', 'p', 'D. NO : 2-38, Contact: Near Ramatemple, Kovvuru, Kakinada Rural-, East Godavari dist., A.P.', '10/10/1997', 'Male', '9908085424', 'photos/logo.jpg', 'uday', '12th  December 2016'),
('ID:33554687', 'Uday', 'Sree', 'P', '2-38, near ramatemple ,kovvuru', '11/03/1997', 'Male', '9908085424', 'photos/logo.jpg', 'uday', '12th  December 2016'),
('ID:48315430', 'uday sekhar', 'uday', 'u', 'smlkot', '11/03/1997', 'Male', '9542253326', 'photos/logo.jpg', 'uday', '12th  December 2016'),
('ID:67194824', 'Uday', 'sekhar', 'k', 'smlkot', '11/03/1997', 'Male', '9542232258', 'photos/logo1.jpg', 'uday', '12th  December 2016'),
('ID:80178223', 'uday sekhar', 'uday', 'u', 'smlkot', '11/03/1997', 'Male', '9542253326', 'photos/logo.jpg', 'uday', '12th  December 2016');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(22) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '123456',
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `fullname`, `gender`, `address`, `username`, `password`, `role`) VALUES
(12951, 'Bwire Mashauri', 'Male', 'Dar Es Salaam', 'admin', '123456', 'Admin'),
(12952, 'manikanta', 'Male', 'kakinaa', 'mani', 'mani6264', 'Admin'),
(12953, 'uday', 'Male', 'smlkot', 'uday', '123456', 'Standard User'),
(12954, 'uday', 'Male', 'smlkot', 'uday', '123456', 'Standard User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD UNIQUE KEY `regstrationid` (`regstrationid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12955;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
