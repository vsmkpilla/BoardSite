-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2017 at 03:44 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airtel`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(22) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `subject`, `description`, `date`) VALUES
(5, 'MID EXAMS', 'From 1-FEB-17 \r\nTo 7-FEB-17', 'Sunday 22nd  January 2017 07:47:48 AM');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` text NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `mobile`) VALUES
('a', 'a@kk', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `regstrationid` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birthday` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `username` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`regstrationid`, `firstname`, `middlename`, `lastname`, `address`, `birthday`, `gender`, `phonenumber`, `photo`, `signature`, `date`, `username`) VALUES
('ID:14316406', 'satya pendem', 'murthy', 'pendem', 'kkd', '11/03/11', 'Male', '999999999', 'photos/1.JPG', 'satya', '23rd  January 2017', ''),
('ID:30949707', 'manik', 'p', 'm', 'mani@gmail', '22/55/14', 'Male', '3333333333', 'photos/2.JPG', 'mk', '23rd  January 2017', ''),
('ID:32397461', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:32475586', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:33217773', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:34645996', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:35312500', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:35354004', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:38425293', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:39423828', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:40314941', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:40507812', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:41538086', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:41870117', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:42753906', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:42822266', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:43474121', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:44125976', 'sai', 'krishna', 'p', 'kakinada', '11/03/1449', 'Male', '9963966284', 'photos/1.JPG', 'sai', '22nd  January 2017', ''),
('ID:45185547', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:45324707', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:45749512', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:46506348', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:47343750', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:47377930', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:47463379', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:48000488', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:48410645', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:51699219', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:51777344', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:52766113', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:53056641', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:53503418', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:54189453', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:54282227', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:54401856', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:54704590', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:55563965', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:56191406', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:56481934', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:57070313', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:57214356', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:57358399', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:57802734', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:57919922', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:58171387', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:58518067', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:58581543', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:59299317', 'sai', 'Sree', 'p', 'D. NO : 2-38, Contact: Near Ramatemple, Kovvuru, Kakinada Rural-, East Godavari dist., A.P.', '11/03/1449', 'Male', '9908085424', 'photos/2.JPG', 'a', '23rd  January 2017', ''),
('ID:60175781', 'a', 'eee', 'es', 'gbgs', 'dfs', 'Male', '1111', 'photos/2.JPG', 'mk', '23rd  January 2017', ''),
('ID:60363770', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:61494141', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:62316895', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:62336426', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:62451172', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:63210449', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:65002442', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:65358887', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:65490723', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:66721192', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:67370606', 'sai', 'krishna', 'p', 'kakinada', '11/03/1447', 'Male', '9963966284', 'photos/1.JPG', 'mani', '22nd  January 2017', ''),
('ID:68950196', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:70666504', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:71242676', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:73540039', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:74138184', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:76032715', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:76833496', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:78559571', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:79201661', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:80678711', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:82478028', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:83869629', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:84155274', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:85788575', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:86430665', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:87407227', 'mk', 'aa', 'bb', 'kajkj', 'nsdkafhd', 'Male', '77777', 'photos/1.JPG', 'mk', '23rd  January 2017', ''),
('ID:88312989', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', ''),
('ID:88552247', 'mkp', 'mkp', 'mkp', 'kkd', '11/03/11', 'Male', '999999999', 'photos/1.JPG', 'mkp', '23rd  January 2017', ''),
('ID:88613282', 'sai', 'KRISHNA', 'P', 'KAKINADA', '11/03/1447', 'Male', '9963966284', 'photos/1.JPG', 'mani', '22nd  January 2017', ''),
('ID:89340821', '', '', '', '', '', '', '', 'photos/', 'mani', '22nd  January 2017', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(22) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '123456',
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `fullname`, `gender`, `address`, `username`, `password`, `role`) VALUES
(12951, 'Bwire Mashauri', 'Male', 'Dar Es Salaam', 'admin', '123456', 'Admin'),
(12952, 'manikanta', 'Male', 'kakinaa', 'mani', 'mani6264', 'Admin'),
(12962, 'manikanta', 'Male', 'kakinada', 'manik', '123456', 'Admin'),
(12963, 'uday', 'Male', 'Samalkot', 'uday', 'uday', 'Admin'),
(12964, 'PawanKalyan', 'Male', 'Rajahmundry', 'pawan', 'pawan', 'Admin'),
(12965, 'Sai', 'Male', 'kakinada', 'sai', '123456', 'Standard User'),
(12966, 'mk', 'Male', 'kakinada', 'mk', '123456', 'Standard User'),
(12967, 'mk', 'Male', 'kakinafa', 'mani', '123456', 'Standard User'),
(12968, 'Mani', 'Male', 'kkd', 'mk', '123456', 'Standard User'),
(12969, 'Mani', 'Male', 'kkd', 'mk', '123456', 'Standard User'),
(12970, 'mkp', 'Male', 'kkd', 'mkp', '123456', 'Standard user'),
(12971, 'a', 'Male', 'a', 'a', '123456', 'Standard user'),
(12972, 'satya', 'Male', 'kkd', 'satya', '123456', 'Standard user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD UNIQUE KEY `regstrationid` (`regstrationid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12973;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
