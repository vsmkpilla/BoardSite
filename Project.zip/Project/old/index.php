
<html>
	<head>
		<title>E-Notice Board</title>
		<link rel="stylesheet" href="css/bootstrap.css"/>
		<script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-3.1.1.js"></script>
<script type="text/javascript">
 $(function(){
    $("form").hide();
   $("#c").click(function(){
	   $("form").toggle(1500);
   });
   });
   </script>
	</head>
	<body>
			<nav class="" >
  <div class="container">
      
     <center><a href="index.php" style="text-decoration:none"><b><font color="white" face="Tahoma, Geneva, sans-serif" size="12" >Smart E-Notice Board</font></b></a>      	


<ul class="nav navbar-nav navbar-right">
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span><font color="black" size="4"> Login</font></a></li>
    </ul>



</div>
</nav>	

<div class="container-fluid">
	<!-- slider -->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="homeimg/1.jpg" alt="...">
      <div class="carousel-caption">
        ..........
      </div>
    </div>
    <div class="item">
      <img src="homeimg/2.jpg" alt="...">
      <div class="carousel-caption">
       ...
      </div>
    </div>
	
	 <div class="item">
      <img src="homeimg/3.jpg" alt="...">
      <div class="carousel-caption">
        ..........
      </div>
    </div>
    <div class="item">
      <img src="homeimg/3.jpg" alt="...">
      <div class="carousel-caption">
        outside
      </div>
    </div>
    Gallery
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- slider end-->
</div>
<div class="container">
  <div class="row">
   <marquee direction="left" bgcolor="#CCCCCC" width="500" height="20"><font color="green">Aditya Polytechnic College</font></marquee>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
   <marquee direction="left" bgcolor="#CCCCCC" width="500" height="20"><font color="green">Aditya Polytechnic College</font></marquee>
    </div>
    </div>
<div class="container">
	<div class="row">
	<!-- container -->
		<div class="col-sm-8">
		<h1><i><b><font color="#FFFFFF">E-NOTICE BOARD</font></b></i></h1>
        <p><font size="3" color="white">E-notice board system or ENS is a Web Application that allows the users to connect to the NoticeBoard.Once logged in, the user can See the Notices Posted By College Administration... And Can able to make the Notice Requests....</font></p>
		
		
		
		
		</div>
	<!-- container -->
   	<div class="col-sm-4">
			<div class="panel panel-default">
  <div class="panel-heading"> <button id="c"><font face="Trebuchet MS, Arial, Helvetica, sans-serif" size="6">Contact Us</font></button></div>
  <div class="panel-body">
 
     <form action="index.php" method="post" id="form">
     <table>
     <tr>
     <td><font color="black">Name:</font></td><td><input type="text" name="n" required></td></tr>
     <tr><td><font color="black">E-mail:</font></td><td><input type="email" name="e" required></td></tr>
      <tr><td><font color="black">Mobile Number:</font></td><td><input type="number" name="mb" required></td></tr>
      <tr><td> </td><td><input type="submit" value="SUBMIT" name="submit"></td></tr>
     </table>
 </form>
   <?php
if(isset($_POST['submit'])) {
$name = $_POST['n'];
$email = $_POST['e'];
$mbno = $_POST['mb'];


include 'database_configuration.php';

$sql = "INSERT INTO contact (name, email, mobile)
VALUES ('$name', '$email', '$mbno')";

if ($conn->query($sql) === TRUE) {
 echo '<center><font color="#33FF00" size="4">success</font>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>
  </div>
</div>
		
		</div>
	</div>

</div>

<br/>
<br/>
<br/>
<br/>
<!-- footer-->

			<nav class="navbar navbar-default navbar-bottom" style="background:white">
  <div class="container">
  
  
    <center><marquee direction="right" bgcolor="#33FF00" id="l">Developed By GURUS</marquee>
      
	




</div>
</nav>
<!-- footer-->

	</body>
</html>